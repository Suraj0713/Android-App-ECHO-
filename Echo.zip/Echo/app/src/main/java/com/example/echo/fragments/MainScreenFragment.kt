package com.example.echo.fragments


import android.app.Activity
import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.provider.MediaStore.Audio.Media
import android.util.Log
import android.view.*
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.echo.CurrentSongHelper
import com.example.echo.R
import com.example.echo.Songs
import com.example.echo.adapters.MainScreenAdapter
import com.example.echo.fragments.MainScreenFragment.Statified.mMediaPlayer
import java.util.*
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 */
@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS", "DEPRECATION")
class MainScreenFragment : Fragment() {
    private var getSongsList: ArrayList<Songs>? = null
    private var nowPlayingBottomBar: RelativeLayout? = null
    private var playPauseButton: ImageButton? = null
    private var songTitle: TextView? = null
    private var visibleLayout: RelativeLayout? = null
    private var noSongs: RelativeLayout? = null
    private var recyclerView: RecyclerView? = null
    private var myActivity: Activity? = null
    private var mainScreenAdapter: MainScreenAdapter? = null
    private var playPauseHelper: CurrentSongHelper? = null

    object Statified {
        var mMediaPlayer: MediaPlayer? = null
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_main_screen, container, false)
        setHasOptionsMenu(true)
        activity?.title = "All Songs"
        visibleLayout = view?.findViewById(R.id.visibleLayout)
        noSongs = view?.findViewById(R.id.noSongs)
        nowPlayingBottomBar = view?.findViewById(R.id.hiddenBarMainScreen)
        songTitle = view?.findViewById(R.id.songTitleMainScreen)
        playPauseButton = view?.findViewById(R.id.playPauseButton)
        recyclerView = view?.findViewById(R.id.contentMain)
        playPauseHelper?.isPlaying = false
        //make the no songs layout visible
        if (getSongsList == null) {
            getSongsList = getSongsFromPhone()
            if (getSongsList == null) {
                visibleLayout?.visibility = View.INVISIBLE
                noSongs?.visibility = View.VISIBLE
            }
        } else {
            Log.d(MainScreenFragment::class.java.simpleName, " Data already there")
        }

        mainScreenAdapter = MainScreenAdapter(getSongsList as ArrayList<Songs>, activity)
        val mLayoutManager = LinearLayoutManager(activity)
        (recyclerView as RecyclerView).layoutManager = mLayoutManager
        (recyclerView as RecyclerView).itemAnimator = DefaultItemAnimator()
        (recyclerView as RecyclerView).adapter = mainScreenAdapter
        return view

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        bottomBarSetup()
        playPauseHelper = CurrentSongHelper()


        val prefs = activity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)
        val actionSortAscending = prefs?.getString("action_sort_ascending", "true")
        val actionSortRecent = prefs?.getString("action_sort_recent", "false")

        if (getSongsList == null) {
            visibleLayout?.visibility = View.INVISIBLE
            noSongs?.visibility = View.VISIBLE
        } else {
            mainScreenAdapter =
                MainScreenAdapter(getSongsList as ArrayList<Songs>, myActivity as Context)
            val mLayoutManager = LinearLayoutManager(myActivity)
            recyclerView?.layoutManager = mLayoutManager
            recyclerView?.itemAnimator = DefaultItemAnimator()
            recyclerView?.adapter = mainScreenAdapter
        }
        if (getSongsList != null) {
            if (actionSortAscending!!.equals("true", true)) {
                Collections.sort(getSongsList, Songs.Statified.nameComparator)
                mainScreenAdapter?.notifyDataSetChanged()
            } else if (actionSortRecent!!.equals("true", true)) {
                Collections.sort(getSongsList, Songs.Statified.dateComparator)
                mainScreenAdapter?.notifyDataSetChanged()
            }
        }
        bottomBarSetup()

    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        menu?.clear()
        inflater?.inflate(R.menu.main, menu)
        return
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val switcher = item?.itemId
        if (switcher == R.id.action_sort_ascending) {
            val editorOne =
                myActivity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
            editorOne?.putString("action_sort_ascending", "true")
            editorOne?.putString("action_sort_recent", "false")
            editorOne?.apply()
            if (getSongsList != null) {
                Collections.sort(getSongsList, Songs.Statified.nameComparator)
            }
            mainScreenAdapter?.notifyDataSetChanged()
            return false
        } else if (switcher == R.id.action_sort_recent) {
            val editorTwo =
                myActivity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
            editorTwo?.putString("action_sort_recent", "true")
            editorTwo?.putString("action_sort_ascending", "false")
            editorTwo?.apply()
            if (getSongsList != null) {
                Collections.sort(getSongsList, Songs.Statified.dateComparator)
            }
            mainScreenAdapter?.notifyDataSetChanged()
            return false
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        myActivity = context as Activity
    }

    override fun onAttach(activity: Activity?) {
        super.onAttach(activity)
        myActivity = activity
    }

    override fun onResume() {
        super.onResume()
        Log.d("MainScreen", " onResume")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("MainScreen", " onCreate")
    }


    private fun getSongsFromPhone(): ArrayList<Songs> {
        val arrayList = ArrayList<Songs>()
        val contentResolver = myActivity?.contentResolver
        val songUri = Media.EXTERNAL_CONTENT_URI
        val songCursor = contentResolver?.query(songUri, null, null, null, null)
        if (songCursor != null && songCursor.moveToFirst()) {
            val songId = songCursor.getColumnIndex(Media._ID)
            val songTitle = songCursor.getColumnIndex(Media.TITLE)
            val songArtist = songCursor.getColumnIndex(Media.ARTIST)
            val songData = songCursor.getColumnIndex(Media.DATA)
            val dateIndex = songCursor.getColumnIndex(Media.DATE_ADDED)
            while (songCursor.moveToNext()) {
                val currentId = songCursor.getLong(songId)
                val currentTitle = songCursor.getString(songTitle)
                val currentArtist = songCursor.getString(songArtist)
                val currentData = songCursor.getString(songData)
                val currentDate = songCursor.getLong(dateIndex)
                arrayList.add(
                    Songs(
                        currentId,
                        currentTitle,
                        currentArtist,
                        currentData,
                        currentDate
                    )
                )
            }
        }


        return arrayList
    }

    private fun bottomBarSetup() {
        nowPlayingBottomBar?.isClickable = false
        bottomBarClickHandlers()
        try {
            songTitle?.text = SongPlayingFragment.Statified.currentSongHelper?.songTitle.toString()
            SongPlayingFragment.Statified.mediaPlayer?.setOnCompletionListener {
                SongPlayingFragment.Staticated.onSongComplete()
                songTitle?.text =
                    SongPlayingFragment.Statified.currentSongHelper?.songTitle.toString()
            }
            if (SongPlayingFragment.Statified.mediaPlayer?.isPlaying as Boolean) {

                playPauseHelper?.isPlaying = true
                nowPlayingBottomBar?.visibility = View.VISIBLE
                nowPlayingBottomBar?.layoutParams?.height = RecyclerView.LayoutParams.WRAP_CONTENT
                nowPlayingBottomBar?.setPadding(0, 11, 0, 11)
                nowPlayingBottomBar?.requestLayout()
            } else {
                playPauseHelper?.isPlaying = false
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    private fun bottomBarClickHandlers() {

        nowPlayingBottomBar?.setOnClickListener {


            try {
                mMediaPlayer = SongPlayingFragment.Statified.mediaPlayer
                val songPlayingFragment = SongPlayingFragment()
                val fetchFromSongsFragment = SongPlayingFragment.Statified.fetchSongs
                val args = Bundle()

                args.putString("BottomBar", "true")
                args.putString(
                    "songTitle",
                    SongPlayingFragment.Statified.currentSongHelper?.songTitle
                )
                args.putString(
                    "songArtist",
                    SongPlayingFragment.Statified.currentSongHelper?.songArtist
                )
                args.putInt(
                    "songPosition",
                    SongPlayingFragment.Statified.currentSongHelper!!.currentPosition
                )
                args.putInt(
                    "SongId",
                    SongPlayingFragment.Statified.currentSongHelper?.songId!!.toInt()
                )
                args.putParcelableArrayList("songsData", fetchFromSongsFragment)
                songPlayingFragment.arguments = args
                fragmentManager?.beginTransaction()
                    ?.replace(R.id.details_fragment, songPlayingFragment)
                    ?.addToBackStack("MainScreenFragment")
                    ?.commit()
            } catch (e: Exception) {
                Toast.makeText(activity, "Something went wrong", Toast.LENGTH_SHORT).show()
                e.printStackTrace()
            }
        }

        playPauseButton?.setOnClickListener {
            if (playPauseHelper?.isPlaying as Boolean) {
                SongPlayingFragment.Statified.mediaPlayer?.pause()
                playPauseHelper?.trackPosition =
                    SongPlayingFragment.Statified.mediaPlayer?.currentPosition!!
                playPauseHelper?.isPlaying = false
                playPauseButton?.setBackgroundResource(R.drawable.play_icon)
            } else {
                SongPlayingFragment.Statified.mediaPlayer?.seekTo((playPauseHelper as CurrentSongHelper).trackPosition)
                SongPlayingFragment.Statified.mediaPlayer?.start()
                playPauseHelper?.isPlaying = true
                playPauseButton?.setBackgroundResource(R.drawable.pause_icon)
            }
        }

    }


}
