package com.example.echo.databases

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.echo.Songs
import java.lang.Exception

class EchoDatabase: SQLiteOpenHelper{
    constructor(
        context: Context?,
        name: String?,
        factory: SQLiteDatabase.CursorFactory?,
        version: Int
    ): super(context, name, factory, version)
    constructor(
        context: Context?
    ): super(context, Staticated.DB_NAME,null, Staticated.DB_VERSION)

    private var songList = ArrayList<Songs>()


    object Staticated{
        var DB_VERSION = 13
        const val DB_NAME = "FavoriteDatabase"
        const val TABLE_NAME = "Favorite"
        const val COLUMN_ID = "SongID"
        const val COLUMN_SONG_TITLE = "SongTitle"
        const val COLUMN_SONG_ARTIST = "SongArtist"
        const val COLUMN_SONG_PATH = "SongPath"
    }


    override fun onCreate(sqLiteDatabase:  SQLiteDatabase?) {
        sqLiteDatabase?.execSQL("CREATE TABLE " + Staticated.TABLE_NAME + "(" + Staticated.COLUMN_ID + " INTEGER," + Staticated.COLUMN_SONG_ARTIST + " TEXT," +
                Staticated.COLUMN_SONG_TITLE + " TEXT," + Staticated.COLUMN_SONG_PATH + " TEXT);")

    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {

    }
    fun storeAsFavorite(id: Int?, artist: String?, songTitle: String?, path: String?){
        val db =this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(Staticated.COLUMN_ID,id)
        contentValues.put(Staticated.COLUMN_SONG_ARTIST,artist)
        contentValues.put(Staticated.COLUMN_SONG_TITLE,songTitle)
        contentValues.put(Staticated.COLUMN_SONG_PATH,path)
        db.insert(Staticated.TABLE_NAME, null,contentValues)
        db.close()
    }
    fun queryDBList(): ArrayList<Songs>?{
        try {
            val db = this.readableDatabase
            val queryParams = "SELECT * FROM " + Staticated.TABLE_NAME
            val  cSor = db.rawQuery(queryParams,null)
            if (cSor.moveToFirst()){
                do {
                    val id = cSor.getInt(cSor.getColumnIndexOrThrow(Staticated.COLUMN_ID))
                    val artist = cSor.getString(cSor.getColumnIndexOrThrow(Staticated.COLUMN_SONG_ARTIST))
                    val  title = cSor.getString(cSor.getColumnIndexOrThrow(Staticated.COLUMN_SONG_TITLE))
                    val  songPath = cSor.getString(cSor.getColumnIndexOrThrow(Staticated.COLUMN_SONG_PATH))
                    songList.add(Songs(id.toLong(),title,artist,songPath,0))
                }while (cSor.moveToNext())
            } else{
                return null
            }
        }catch (e:Exception){
            e.printStackTrace()
        }
      return songList
    }
    fun checkIfIdExists(_id: Int): Boolean{
        var storeId: Int
        val db = this.readableDatabase
        val queryParams = "SELECT * FROM " + Staticated.TABLE_NAME + " WHERE SongId =  '$_id' "
        val cSor = db.rawQuery(queryParams,null)
        if (cSor.moveToFirst()) {
            do {
                storeId = cSor.getInt(cSor.getColumnIndexOrThrow(Staticated.COLUMN_ID))
            } while (cSor.moveToNext())
        }else{
            return false
        }
        return storeId != -1090
    }
    fun deleteFavorite(_id: Int){
        val db = this.writableDatabase
        db.delete(Staticated.TABLE_NAME,Staticated.COLUMN_ID + "=" + _id, null)
        db.close()
    }
    fun checkSize(): Int{
        var counter = 0
        val db = this.readableDatabase
        val queryParams = "SELECT " + "*" + " FROM " + Staticated.TABLE_NAME
        val cSor = db.rawQuery(queryParams,null)
        if (cSor.moveToFirst()){
            do {
                counter += 1
            }while (cSor.moveToNext())
        }else{
            return 0
        }
        return counter
    }
}